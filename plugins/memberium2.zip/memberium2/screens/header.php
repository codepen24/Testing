<img src="//memberium.s3.amazonaws.com/img/m4is-logo.gif" style="width:125px !important; height:170px !important;float:right; border-radius:10px;">
<h3 style="margin-top:0px;margin-bottom:-10px;font-weight:normal;font-size:280%;"><?php
echo _('Welcome to Memberium' ), ' ', memberium_app()->wpalm4is_zktb2lnm(); ?></h3>
<div class="about-text">
<?php
echo _e('We&rsquo;re activated and ready to help you build your own private Membership community.<br /><br />' ); ?>
</div>
