<?php
if (!defined('ABSPATH' ) ) { die(); } echo wpalm4is_chwfbm('resources' );
