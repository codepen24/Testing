<?php
/**
 * Copyright (c) 2020 David J Bullock
 * Web Power and Light
 */



if ( !defined( 'ABSPATH' ) ) {
    die();
}

if ( is_admin() ) {
    echo '<p>Debug</p>';
}
