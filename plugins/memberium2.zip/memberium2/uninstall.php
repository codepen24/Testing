<?php
/**
 * Copyright (C) 2020 David Bullock
 * Web Power and Light, LLC
 */

 if (! defined('WP_UNINSTALL_PLUGIN') ) { return; }
