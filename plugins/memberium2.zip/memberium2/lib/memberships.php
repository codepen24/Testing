<?php
/**
 * Copyright (c) 2012-2020 David J Bullock
 * Web Power and Light, LLC
 * https://webpowerandlight.com
 * support@webpowerandlight.com
 *
 */

 if (! defined('ABSPATH') ) { die(); } final class wpalm4is_i9_z7pq0s5h2 { function __construct($vwpalm4is_vzoj7cv_rsly = 0) { } static function wpalm4is_d3knudatsq_() { $vwpalm4is_la4pzw = wpalm4is_xb7t0i6pzn::wpalm4is_s0xuab5fq6hy('memberships'); $vwpalm4is_c7fqlc_hbw6a = array(); foreach($vwpalm4is_la4pzw as $vwpalm4is_vzoj7cv_rsly => $vwpalm4is_mp_ceis8) { $vwpalm4is_c7fqlc_hbw6a[$vwpalm4is_vzoj7cv_rsly] = $vwpalm4is_mp_ceis8['name']; } return $vwpalm4is_c7fqlc_hbw6a; } }
