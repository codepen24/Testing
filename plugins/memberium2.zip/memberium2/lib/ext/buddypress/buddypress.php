<?php
 if ( !defined( 'ABSPATH' ) ) { die(); } require_once __DIR__ . '/lib/main.php';
