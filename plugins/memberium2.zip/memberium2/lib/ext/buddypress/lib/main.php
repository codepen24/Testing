<?php
if ( !defined( 'ABSPATH' ) ) { die(); }  if (! function_exists('bp_is_active') ) { return; } new wpalm4is_jhqro0jwe; add_action('bp_include', 'wpalm4is_pfz5r_b7w1t' ); if (! function_exists( 'wpalm4is_tj25sv0xbip') ) { function wpalm4is_pfz5r_b7w1t() { $my_path = __DIR__ . '/'; if (bp_is_active('groups') ) { require_once $my_path . 'groups.php'; } } }
