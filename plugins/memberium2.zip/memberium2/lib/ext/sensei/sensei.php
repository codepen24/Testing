<?php
 if ( ! defined( 'ABSPATH' ) ) { die(); } new wpalm4is_x2e4_ry;
