<?php
if ( !defined( 'ABSPATH' ) ) { die(); } if ( ! wpalm4is_rvrqgfe5ns_::wpalm4is_c8me3ltrxcn4() ) { return; } if ( class_exists( 'LearnPress' ) ) { if (intval(LEARNPRESS_VERSION) >= 3 ) { new wpalm4is_pyj3gzpcnf; } else {  } }
