<?php
 if ( ! defined( 'ABSPATH' ) ) { die(); } final class wpalm4is_c2g9jfutd0om { }
