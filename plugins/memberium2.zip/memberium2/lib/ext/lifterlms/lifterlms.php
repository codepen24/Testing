<?php
if ( !defined( 'ABSPATH' ) ) { die(); }  if ( true || defined( 'LLMS_VERSION' ) ) { new wpalm4is_wd5e3i8p4w; if (is_admin() ) { require_once __DIR__ . '/admin.php'; } else { require_once __DIR__ . '/frontend.php'; } }
