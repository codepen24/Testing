<?php
 if ( ! defined( 'ABSPATH' ) ) { die(); } if ( ! is_admin() ) { require_once __DIR__ . '/system.php'; }
