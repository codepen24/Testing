<?php
/**
 * Copyright (c) 2012-2020 David J Bullock
 * Web Power and Light
 */

 if (! defined( 'ABSPATH' ) ) { die(); }
