<?php
/**
 * Copyright (C) 2020 David Bullock
 * Web Power and Light, LLC
 */

 if (! defined('ABSPATH') ) { header('HTTP/1.0 403 Forbidden'); die(); } class wpalm4is_c_nfq846zd { }
