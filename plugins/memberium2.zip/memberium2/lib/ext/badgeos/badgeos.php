<?php
if ( !defined( 'ABSPATH' ) ) { die(); } if (! class_exists('BadgeOS') ) { return; } if (! wpalm4is_rvrqgfe5ns_::wpalm4is_c8me3ltrxcn4() ) { return; } new wpalm4is_a58l2mftx9y4; if ( is_admin() ) { new wpalm4is_njq2i76; }
