<?php
/**
* Copyright (c) 2020-2020 David J Bullock
 * Web Power and Light, LLC
 * https://webpowerandlight.com
 * support@webpowerandlight.com
 *
 */

 if (! defined('ABSPATH') ) { die(); } final class wpalm4is_x8c513 { function wpalm4is_ktcves81() { $vwpalm4is_qukvxygid3b = trim(strtolower($_GET['operation']) ); $vwpalm4is_tgqojl1zwn96 = array( 'delete-user' => array($this, 'wpalm4is_mbel21jn8mh'), ); $vwpalm4is_tgqojl1zwn96 = apply_filters('memberium/httpppost_services/register', $vwpalm4is_tgqojl1zwn96); if (array_key_exists($vwpalm4is_qukvxygid3b, $vwpalm4is_tgqojl1zwn96) ) { $vwpalm4is_xsxnaocd3j8f = $vwpalm4is_tgqojl1zwn96[$vwpalm4is_qukvxygid3b]; } } private function wpalm4is_mbel21jn8mh() { } function __construct() { } }
