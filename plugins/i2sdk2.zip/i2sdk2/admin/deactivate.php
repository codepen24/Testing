<?php
if (!defined('ABSPATH')) {
    die();
}


function wpal_i2sdk_deactivate() {

}