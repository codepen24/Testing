<?php
if (!defined('ABSPATH')) {
    die();
}


register_uninstall_hook(__FILE__, 'wpal_i2sdk_uninstall' );


function wpal_i2sdk_uninstall() {

}