<?php get_header(); ?>

<?php echo do_shortcode(' [elementor-template id="34359"]  '); ?>  

<?php get_sidebar(); ?>

<?php get_footer(); ?>
